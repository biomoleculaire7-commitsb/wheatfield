# 🌾 WheatField × Band — Multi-Agent Drone Agricultural System

> **Band of Agents Hackathon** — Track 3: Regulated & High-Stakes Workflows
> Deadline: June 19, 2026

---

## What It Does

**WheatField** is a drone simulation platform that:
1. Captures wheat field images + sensor data (temp, humidity, GPS, altitude)
2. Routes everything through a **Band multi-agent pipeline**
3. Delivers a structured payload to the **WheatGuard Android App** for disease detection

---

## Band Agent Pipeline

```
WheatField Web Platform
        │
        │  HTTP POST /drone/payload
        ▼
  Platform Connector (port 8080)
        │
        │  Forward to Band agent
        ▼
  ╔══════════════════════════════════════╗
  ║     Band Room: wheat-field-ops       ║
  ║                                      ║
  ║  @collector → validates raw payload  ║
  ║      │                               ║
  ║      ▼ @mention                      ║
  ║  @packager  → structures JSON bundle ║
  ║      │                               ║
  ║      ▼ @mention                      ║
  ║  @transmitter → POSTs to app         ║
  ╚══════════════════════════════════════╝
        │
        │  HTTP POST /api/analyze
        ▼
  WheatGuard Android App
  (detects wheat disease)
```

### Why This Satisfies Band Hackathon Requirements

| Requirement | How We Meet It |
|-------------|---------------|
| ≥ 3 agents through Band | @collector, @packager, @transmitter — all in Band room |
| Real collaboration layer | @mention routing drives the entire pipeline |
| Cross-framework | Anthropic adapter orchestrates all 3 roles |
| Structured handoff | Each agent passes JSON context to the next |
| Track 3: Regulated workflow | Agricultural disease detection (high-stakes) |

---

## Band Credentials

```yaml
agent_id: ee9404c3-2459-4eb5-80e6-ae3579e30c77
handle:   @biomoleculaire7/wheatsheild-diagnostic-a
```

---

## Setup & Run

### 1. Prerequisites

```bash
# Install uv (Python package manager)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Clone / enter project
cd wheatfield-band
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env and fill in:
#   ANTHROPIC_API_KEY=sk-ant-...
#   WHEATGUARD_APP_URL=http://your-android-server:8000/api/analyze
```

### 3. Install Dependencies

```bash
uv sync
```

### 4. Run

**Terminal 1 — Band Agent:**
```bash
uv run python agents/wheatshield_agent.py
```

**Terminal 2 — Platform Connector:**
```bash
uv run python platform/connector.py
```

**Terminal 3 — Test:**
```bash
uv run python test_payload.py
```

Or with Docker:
```bash
docker compose up
```

### 5. Connect WheatField Web Platform

In the WheatField web UI (HTML platform), Agent 3 (Transmitter) should POST to:
```
http://localhost:8080/send
```

---

## Payload Format

```json
{
  "image": "<base64 encoded wheat photo>",
  "temperature": 28.4,
  "humidity": 62,
  "latitude": 35.6841,
  "longitude": 0.6324,
  "altitude": 25,
  "zone": "ZONE-D"
}
```

---

## Band Room Conversation Flow

```
[Platform]      → @collector New drone payload received...
                   INCOMING_PAYLOAD | temp=28.4°C | hum=62% | zone=ZONE-D

[@collector]    → @packager
                   COLLECTOR_DONE | temp=28.4°C | hum=62% | gps=35.68,0.63 | payload={...}

[@packager]     → @transmitter
                   PACKAGER_DONE | mission=WFMS-20260609-4821 | size=42KB | payload={...}

[@transmitter]  → (broadcasts to room)
                   TRANSMITTER_DONE | mission=WFMS-20260609-4821 | status=delivered | app=WheatGuard
```

---

## WheatGuard Android App Integration

When your Android app is ready, set `WHEATGUARD_APP_URL` to your server endpoint.
The app will receive:

```json
{
  "image": "<base64>",
  "temperature": 28.4,
  "humidity": 62,
  "latitude": 35.6841,
  "longitude": 0.6324,
  "altitude": 25,
  "zone": "ZONE-D",
  "timestamp": "2026-06-09T09:41:00Z",
  "mission_id": "WFMS-20260609-4821",
  "source": "WheatField-DroneSimulator-v1"
}
```

The app handles disease detection independently.
