"""
test_payload.py — Quick test
============================
Simulates the WheatField platform sending a drone payload.
Run AFTER the Band agent is running.

Usage:
    uv run python test_payload.py
"""

import asyncio
import base64
import httpx
import json

# Minimal test image (1x1 green pixel PNG, base64)
TEST_IMAGE_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk"
    "YPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
)

TEST_PAYLOAD = {
    "image": TEST_IMAGE_B64,
    "temperature": 28.4,
    "humidity": 62,
    "latitude": 35.6841,
    "longitude": 0.6324,
    "altitude": 25,
    "zone": "ZONE-D",
}


async def main():
    print("🌾 WheatField × Band — Test Payload")
    print("=" * 40)
    print(f"Sending to Platform Connector: http://localhost:8080/send")
    print(f"Payload: temp={TEST_PAYLOAD['temperature']}°C | "
          f"hum={TEST_PAYLOAD['humidity']}% | "
          f"zone={TEST_PAYLOAD['zone']}")
    print()

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                "http://localhost:8080/send",
                json=TEST_PAYLOAD
            )
            result = resp.json()
            print(f"✅ Response ({resp.status_code}):")
            print(json.dumps(result, indent=2))
            print()
            print("🔗 Check the Band room 'wheat-field-ops' to see agents collaborating!")
            print("   https://app.band.ai")

    except httpx.ConnectError:
        print("❌ Could not connect. Make sure the agent is running:")
        print("   uv run python agents/wheatshield_agent.py")
        print("   uv run python platform/connector.py")


if __name__ == "__main__":
    asyncio.run(main())
