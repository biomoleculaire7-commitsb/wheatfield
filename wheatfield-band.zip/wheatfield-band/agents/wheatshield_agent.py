"""
WheatShield Diagnostic Agent — Band Multi-Agent System
======================================================
Agent: @biomoleculaire7/wheatsheild-diagnostic-a
ID:    ee9404c3-2459-4eb5-80e6-ae3579e30c77

This single Band agent orchestrates 3 internal sub-agents through
Band's @mention routing system inside a shared collaboration room.

Architecture:
  WheatField Platform → [HTTP POST] → This Agent (Band Room)
                                           ↓
                              @collector receives raw payload
                              @collector → @packager (validated data)
                              @packager  → @transmitter (structured bundle)
                              @transmitter → WheatGuard Android App
"""

import asyncio
import json
import logging
import os
import base64
import httpx
from datetime import datetime, timezone
from dotenv import load_dotenv

from thenvoi import Agent
from thenvoi.adapters import AnthropicAdapter
from thenvoi.config import load_agent_config

load_dotenv()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s — %(message)s"
)
logger = logging.getLogger("WheatShield")

# ─── Band Room name (all 3 sub-agents live here) ───────────────────────────
BAND_ROOM = "wheat-field-ops"

# ─── WheatGuard Android App endpoint ───────────────────────────────────────
WHEATGUARD_URL = os.getenv("WHEATGUARD_APP_URL", "http://localhost:8000/api/analyze")


# ══════════════════════════════════════════════════════════════════════════════
#  AGENT 1 — COLLECTOR
#  Receives raw drone payload from the WheatField platform
#  Validates fields then @mentions @packager in the Band room
# ══════════════════════════════════════════════════════════════════════════════
COLLECTOR_SYSTEM = """
You are the COLLECTOR agent inside the WheatField multi-agent system.
Your role in the Band room 'wheat-field-ops':

1. You receive raw drone telemetry messages from the WheatField platform.
2. You verify all required fields are present:
   - image (base64 string)
   - temperature (float, °C)
   - humidity (int, %)
   - latitude (float)
   - longitude (float)
   - altitude (int, meters)
   - zone (string: ZONE-D or ZONE-N)
3. You add a received_at timestamp.
4. You forward to @packager with this EXACT format:

   COLLECTOR_DONE | temp={temperature}°C | hum={humidity}% | gps={lat},{lon} | alt={alt}m | zone={zone} | img_size={kb}KB | payload={json}

If any field is missing, respond:
   COLLECTOR_ERROR | missing={field_name} | Please re-send from WheatField platform.

Always be concise. You are part of an agricultural drone monitoring system.
"""


# ══════════════════════════════════════════════════════════════════════════════
#  AGENT 2 — PACKAGER
#  Receives validated data from @collector
#  Structures it into a clean JSON bundle then @mentions @transmitter
# ══════════════════════════════════════════════════════════════════════════════
PACKAGER_SYSTEM = """
You are the PACKAGER agent inside the WheatField multi-agent system.
Your role in the Band room 'wheat-field-ops':

1. You receive a COLLECTOR_DONE message from @collector.
2. You extract all fields from the message.
3. You enrich the bundle with:
   - packaged_at: current ISO timestamp
   - source: "WheatField-DroneSimulator-v1"
   - mission_id: auto-generated ID (WFMS-{date}-{random 4 digits})
4. You create a final structured JSON payload.
5. You forward to @transmitter with this EXACT format:

   PACKAGER_DONE | mission={mission_id} | size={total_kb}KB | payload={json}

If you receive COLLECTOR_ERROR, forward it to @transmitter as:
   PACKAGER_ERROR | reason={error} | Awaiting corrected payload.

Always be concise. You are part of an agricultural drone monitoring system.
"""


# ══════════════════════════════════════════════════════════════════════════════
#  AGENT 3 — TRANSMITTER
#  Receives structured bundle from @packager
#  POSTs it to the WheatGuard Android App
#  Reports delivery status back to the Band room
# ══════════════════════════════════════════════════════════════════════════════
TRANSMITTER_SYSTEM = f"""
You are the TRANSMITTER agent inside the WheatField multi-agent system.
Your role in the Band room 'wheat-field-ops':

1. You receive a PACKAGER_DONE message from @packager.
2. You extract the JSON payload.
3. You POST the payload to the WheatGuard Android App at:
   {WHEATGUARD_URL}
4. You report the result back to the room:
   - On success: TRANSMITTER_DONE | mission={{mission_id}} | status=delivered | app=WheatGuard
   - On failure: TRANSMITTER_ERROR | mission={{mission_id}} | status=failed | reason={{error}}

If you receive PACKAGER_ERROR, log:
   TRANSMITTER_SKIP | reason=upstream_error | No payload to transmit.

Always be concise. You are part of an agricultural drone monitoring system.
"""


# ══════════════════════════════════════════════════════════════════════════════
#  HTTP receiver — WheatField platform posts here
# ══════════════════════════════════════════════════════════════════════════════
async def start_http_receiver(band_agent: Agent):
    """
    Tiny HTTP server on port 7777.
    WheatField platform posts drone payload here.
    We forward it to the Band room as a @collector mention.
    """
    from aiohttp import web

    async def handle_drone_payload(request: web.Request) -> web.Response:
        try:
            data = await request.json()
            logger.info(f"📡 Received from WheatField platform: {list(data.keys())}")

            # Build the Band room message — @mentions @collector to start the pipeline
            img_kb = round(len(data.get("image", "")) * 3 / 4 / 1024, 1)
            band_message = (
                f"@collector New drone payload received from WheatField platform.\n"
                f"INCOMING_PAYLOAD | "
                f"temp={data.get('temperature')}°C | "
                f"hum={data.get('humidity')}% | "
                f"gps={data.get('latitude')},{data.get('longitude')} | "
                f"alt={data.get('altitude')}m | "
                f"zone={data.get('zone')} | "
                f"img_size={img_kb}KB | "
                f"payload={json.dumps(data)}"
            )

            # Post to Band room — this triggers the multi-agent pipeline
            await band_agent.send_message(
                room=BAND_ROOM,
                content=band_message
            )
            logger.info(f"✅ Forwarded to Band room '{BAND_ROOM}' → @collector")

            return web.json_response({
                "status": "accepted",
                "message": "Payload forwarded to Band room",
                "room": BAND_ROOM,
                "pipeline": ["@collector", "@packager", "@transmitter", "WheatGuard App"]
            })

        except Exception as e:
            logger.error(f"❌ HTTP receiver error: {e}")
            return web.json_response({"status": "error", "message": str(e)}, status=500)

    app = web.Application()
    app.router.add_post("/drone/payload", handle_drone_payload)
    app.router.add_get("/health", lambda r: web.json_response({"status": "ok", "agent": "WheatShield"}))

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", 7777)
    await site.start()
    logger.info("🌐 HTTP receiver listening on http://0.0.0.0:7777/drone/payload")


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN — Wire everything together
# ══════════════════════════════════════════════════════════════════════════════
async def main():
    logger.info("🌾 WheatShield × Band — Starting multi-agent system")
    logger.info(f"   Band Room  : {BAND_ROOM}")
    logger.info(f"   Agent ID   : ee9404c3-2459-4eb5-80e6-ae3579e30c77")
    logger.info(f"   Handle     : @biomoleculaire7/wheatsheild-diagnostic-a")

    # Load credentials
    agent_id, api_key = load_agent_config("wheatshield_diagnostic")

    # Build the Anthropic-powered adapter
    # This single agent listens in the Band room and routes based on @mentions
    from anthropic import AsyncAnthropic
    client = AsyncAnthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

    adapter = AnthropicAdapter(
        client=client,
        model="claude-sonnet-4-20250514",
        # The agent understands all 3 roles through the combined system prompt
        system=(
            "You are the WheatShield Diagnostic orchestrator inside Band room 'wheat-field-ops'.\n"
            "You coordinate 3 sub-agents through @mention routing:\n\n"
            "When you receive INCOMING_PAYLOAD → act as @collector:\n"
            + COLLECTOR_SYSTEM + "\n\n"
            "When you receive COLLECTOR_DONE → act as @packager:\n"
            + PACKAGER_SYSTEM + "\n\n"
            "When you receive PACKAGER_DONE → act as @transmitter:\n"
            + TRANSMITTER_SYSTEM
        ),
    )

    # Create the Band agent
    agent = Agent.create(
        adapter=adapter,
        agent_id=agent_id,
        api_key=api_key,
    )

    # Start HTTP receiver in background
    await start_http_receiver(agent)

    logger.info("🤖 WheatShield agent connected to Band. Listening for drone payloads...")
    logger.info("   → Send drone data to: POST http://localhost:7777/drone/payload")
    logger.info("   → Pipeline: Platform → Band Room → @collector → @packager → @transmitter → App")

    # Run forever — Band WebSocket keeps agent alive
    await agent.run()


if __name__ == "__main__":
    asyncio.run(main())
