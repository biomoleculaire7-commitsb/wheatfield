"""
WheatField Platform → Band Agent Connector
==========================================
This is the bridge between the WheatField web platform (the drone simulation)
and the Band multi-agent pipeline.

The web platform (HTML/JS) calls POST /drone/payload on THIS server.
This server forwards the payload to the Band agent's HTTP receiver.

Flow:
  WheatField Web UI
      → POST /send (this server)
      → POST /drone/payload (Band agent HTTP receiver on port 7777)
      → Band Room 'wheat-field-ops'
      → @collector → @packager → @transmitter
      → WheatGuard Android App
"""

import asyncio
import json
import logging
import os
import base64
from datetime import datetime, timezone

import httpx
from aiohttp import web
from dotenv import load_dotenv

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s [Platform] — %(message)s")
logger = logging.getLogger("WheatField-Platform")

# Band agent receiver URL
BAND_AGENT_URL = os.getenv("BAND_AGENT_URL", "http://localhost:7777/drone/payload")


async def handle_send(request: web.Request) -> web.Response:
    """
    Receives the drone payload from the WheatField web platform (JS fetch).
    Adds CORS headers so the browser can call it directly.
    Forwards to the Band agent.
    """
    try:
        data = await request.json()

        # Enrich with platform metadata
        payload = {
            "image": data.get("image", ""),           # base64 string
            "temperature": data.get("temperature", 0),
            "humidity": data.get("humidity", 0),
            "latitude": data.get("latitude", 0),
            "longitude": data.get("longitude", 0),
            "altitude": data.get("altitude", 0),
            "zone": data.get("zone", "ZONE-N"),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "platform": "WheatField-DroneSimulator",
            "platform_version": "1.0.0",
        }

        logger.info(
            f"📤 Forwarding to Band agent | "
            f"temp={payload['temperature']}°C | "
            f"hum={payload['humidity']}% | "
            f"zone={payload['zone']}"
        )

        # Forward to Band agent HTTP receiver
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(BAND_AGENT_URL, json=payload)
            result = resp.json()

        logger.info(f"✅ Band agent accepted: {result}")
        return web.json_response({
            "status": "forwarded",
            "band_response": result,
            "pipeline": ["Band Room", "@collector", "@packager", "@transmitter", "WheatGuard App"]
        }, headers={"Access-Control-Allow-Origin": "*"})

    except Exception as e:
        logger.error(f"❌ Error: {e}")
        return web.json_response(
            {"status": "error", "message": str(e)},
            status=500,
            headers={"Access-Control-Allow-Origin": "*"}
        )


async def handle_options(request: web.Request) -> web.Response:
    """CORS preflight"""
    return web.Response(headers={
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
    })


async def handle_health(request: web.Request) -> web.Response:
    return web.json_response({
        "status": "ok",
        "service": "WheatField Platform Connector",
        "band_agent": BAND_AGENT_URL
    })


def build_app() -> web.Application:
    app = web.Application()
    app.router.add_post("/send", handle_send)
    app.router.add_options("/send", handle_options)
    app.router.add_get("/health", handle_health)
    return app


if __name__ == "__main__":
    app = build_app()
    logger.info("🌐 WheatField Platform Connector on http://0.0.0.0:8080")
    logger.info(f"   → Forwards to Band agent at: {BAND_AGENT_URL}")
    web.run_app(app, host="0.0.0.0", port=8080)
